<?php
/**
*
* search_synonyms [English]
*
* @package language
* @version $Id: search_synonyms.php 197 2009-10-18 20:12:18Z fberci $
* @copyright (c) 2007 �Magyar phpBB K�z�ss�g ford�t�k�
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* Original copyright: (c) 2005 phpBB Group

*
*/

$synonyms = array(
);
?>
